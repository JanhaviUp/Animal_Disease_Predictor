# app.py
from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load trained model and encoder
model = joblib.load('disease_model.pkl')
encoder = joblib.load('encoder.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get user input
    animal = request.form['animal']
    s1 = request.form['s1']
    s2 = request.form['s2']
    s3 = request.form['s3']
    s4 = request.form['s4']
    s5 = request.form['s5']

    try:
        # Prepare input
        row = np.array([[animal, s1, s2, s3, s4, s5]])
        row_encoded = encoder.transform(row)

        # Predict
        prediction = model.predict(row_encoded)[0]
        result = "Yes, it is dangerous." if prediction == 1 else "No, it is not dangerous."
    except Exception as e:
        result = f"Prediction error: {e}"

    return render_template('index.html', prediction=result)

if __name__ == "__main__":
    app.run(debug=True)
