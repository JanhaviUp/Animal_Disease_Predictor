# train_model.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import OrdinalEncoder
import joblib

# Load data
df = pd.read_csv("animal_disease.csv")

# Select relevant columns and clean
cols = ['AnimalName','symptoms1','symptoms2','symptoms3','symptoms4','symptoms5','Dangerous']
df = df[cols].dropna()

# Features and target
X = df[['AnimalName','symptoms1','symptoms2','symptoms3','symptoms4','symptoms5']].copy()
y = df['Dangerous'].map({'Yes':1, 'No':0}).astype(int)

# Encode using OrdinalEncoder that handles unknowns
encoder = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
X_encoded = encoder.fit_transform(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X_encoded, y, test_size=0.2, random_state=42, stratify=y
)

# Train model
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Save model and encoder
joblib.dump(encoder, 'encoder.pkl')
joblib.dump(clf, 'disease_model.pkl')

print(f"Training complete — Test Accuracy: {clf.score(X_test, y_test):.2%}")
